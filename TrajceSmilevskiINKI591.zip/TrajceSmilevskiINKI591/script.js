"use strict";

const counterValue = document.querySelector(".counter-value");
const btnUp = document.querySelector(".btn-up");
const btnDown = document.querySelector(".btn-down");

let number = Number(counterValue.textContent);

btnUp.addEventListener("click", function () {
  number++;
  counterValue.textContent = number;
});

btnDown.addEventListener("click", function () {
  number--;
  counterValue.textContent = number;
});
